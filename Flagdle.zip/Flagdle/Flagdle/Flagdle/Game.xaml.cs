﻿using Plugin.SimpleAudioPlayer;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Flagdle
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Game : ContentPage
    {        
        StackLayout temp = new StackLayout();
        private bool currentOrientationLandscape;
        ISimpleAudioPlayer player = CrossSimpleAudioPlayer.CreateSimpleAudioPlayer();
        Dictionary<string, string> _codeCountry = new Dictionary<string, string>();
        Image flagImage;        
        List<string> optionsList = new List<string>();
        public Entry search;        
        string currentCountry = "";
        int attempt = 0;
        protected override void OnAppearing()
        {
            Settings settings = new Settings();
            base.OnAppearing();
            layout.BackgroundColor = settings.darkToggle ? Color.Black : Color.White;
            search.BackgroundColor = settings.darkToggle ? Color.Black : Color.White;
            search.TextColor = settings.darkToggle ? Color.White : Color.Black;
            search.PlaceholderColor = settings.darkToggle ? Color.White : Color.Gray;
            options.BackgroundColor= settings.darkToggle ? Color.Black :Color.Purple;
            frame.BorderColor = settings.darkToggle ? Color.White : Color.Black;
            temp.BackgroundColor = settings.darkToggle ? Color.Black : Color.White;
            Debug.WriteLine("Appearing");            
        }

        public Game()
        {                        
            StackLayout panel = new StackLayout();
            layout = new StackLayout();
            options = new ListView();

            search = new Entry { Placeholder = "Use this to search"};                   
            
            search.TextChanged += Search_TextChanged;
            flagImage = new Image { HeightRequest = 300 };
            newGame();
            optionsList.Sort();
            options.ItemsSource = optionsList;
            options.ItemSelected += Options_ItemSelected;

            frame = new Frame
            {
                Content = flagImage,                
                VerticalOptions = LayoutOptions.CenterAndExpand
            };

            flagdleLabel = new Label
            {
                FontSize = 30,
                BackgroundColor = Color.Purple,
                TextColor = Color.White,
                HorizontalOptions = LayoutOptions.CenterAndExpand,
                Text = "Flag-dle: Wordle for flags"
            };

            panel.Children.Add(flagdleLabel);
            panel.Children.Add(search);
            panel.Children.Add(frame);
            
            layout = panel;
            vert = new StackLayout();
            vert.Children.Add(options);            
                                    
            temp.Children.Add(layout);
            temp.Children.Add(vert);
            Content= temp;
        }

        protected override void OnSizeAllocated(double width, double height)
        {
            base.OnSizeAllocated(width, height);
            bool isNowLandscape = width > height;
            if (isNowLandscape != currentOrientationLandscape)
            {
                temp.Orientation = isNowLandscape ? StackOrientation.Horizontal : StackOrientation.Vertical;                
                currentOrientationLandscape = isNowLandscape;
            }
        }

        private void Load(string file)
        {
            var assembly = typeof(App).GetTypeInfo().Assembly;
            String ns = "Flagdle";
            Stream audioStream = assembly.GetManifestResourceStream(ns + "." + file);
            player.Load(audioStream);
            player.Volume = 0.2;
        }

        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(e.NewTextValue))
            {
                options.ItemsSource = optionsList;
            }

            else
            {
                options.ItemsSource = optionsList.Where(x => x.StartsWith(e.NewTextValue, StringComparison.OrdinalIgnoreCase));               
            }
        }

        private void newGame()
        {
            string filePath = getRandomFlag();
            flagImage.Source = "images/" + filePath + ".png";
            Debug.WriteLine(flagImage.Source);
        }

        async void Options_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            ListView temp = (ListView)sender;
            Settings newSett = new Settings();
            Record newRec = new Record();
            if (attempt < 5)
            {                
                try
                {
                    string country = "";
                    attempt++;
                    if (temp.SelectedItem != null)
                        country = temp.SelectedItem.ToString();
                    else
                        attempt--;
                    string key = _codeCountry.First(x => x.Value.ToString() == country).Key;
                    key = "File: images/" + key + ".png";
                    Debug.WriteLine(key);
                    Debug.WriteLine(flagImage.Source.ToString());
                    Debug.WriteLine(flagImage.Source.ToString().Trim().Equals(key.Trim()));
                    bool isCorrect = flagImage.Source.ToString().Trim().Equals(key.Trim());
                    if (isCorrect)
                    {
                        if (newSett.name != null && !newSett.name.Equals("") && !newSett.name.Equals("guest") && newSett.name.All(Char.IsLetter))
                        {
                            bool update = false;
                            foreach (Records rec in newRec.pubLV.ItemsSource)
                            {
                                if (rec.Name.Equals(newSett.name))
                                {
                                    Debug.WriteLine("Update");
                                    newRec.UpdateClicked(newSett.name, true);
                                    update = true;
                                }

                            }
                            if (!update)
                            {
                                Debug.WriteLine("Add");
                                newRec.AddClicked(newSett.name, true);
                            }
                        }
                        Load("victory.mp3");
                        player.Play();
                        await DisplayAlert("Game Status", "You WON!\nAttempts: " + attempt, "OK");
                        newGame();
                        attempt = 0;
                    }
                    else
                    {
                        Load("incorrect.mp3");
                        player.Play();
                        await DisplayAlert("Game Status", "Incorrect!\nAttempts: " + attempt, "OK");
                    }
                }
                catch (Exception )
                {
                    Debug.WriteLine("Exception");
                }                
            }
            else
            {
                if (newSett.name != null && !newSett.name.Equals("") && !newSett.name.Equals("guest") && newSett.name.All(Char.IsLetter))
                {
                    bool update = false;
                    foreach (Records rec in newRec.pubLV.ItemsSource)
                    {
                        if (rec.Name.Equals(newSett.name))
                        {
                            Debug.WriteLine("Update");
                            newRec.UpdateClicked(newSett.name, false);
                            update = true;
                        }

                    }
                    if (!update)
                    {
                        Debug.WriteLine("Add");
                        newRec.AddClicked(newSett.name, false);
                    }
                }
                Load("gameover.mp3");
                player.Play();
                await DisplayAlert("Game Status", "You LOST!\nCorrect Answer: " + currentCountry, "OK");
                newGame();
                attempt = 0;
            }
        }

        private string getRandomFlag()
        {
            string[] cards = new string[] { "" };
            if (_codeCountry.Count == 0)
            {
                var assembly = typeof(MainPage).GetTypeInfo().Assembly;
                Stream stream = assembly.GetManifestResourceStream("Flagdle.codes.txt");
                string text = "";

                using (var reader = new System.IO.StreamReader(stream))
                {
                    text = reader.ReadToEnd();
                }
                cards = text.Split('\n');

                foreach (string card in cards)
                {
                    Debug.WriteLine(card);
                    string t = "";
                    string[] temp = new string[] { "" };
                    t = card.Replace("\"", "");
                    temp = t.Split(':');
                    _codeCountry.Add(temp[0].Trim(), temp[1].Replace(",", "").Trim());
                    optionsList.Add(temp[1].Replace(",", "").Trim());
                }
            }
            Random rnd = new Random();
            int a = rnd.Next(0, _codeCountry.Count);
            Debug.WriteLine(a);

            currentCountry = _codeCountry.ElementAt(a).Value;
            Debug.WriteLine(_codeCountry.ElementAt(a).Key);
            Debug.WriteLine(currentCountry);
            return _codeCountry.ElementAt(a).Key;
        }
    }
}