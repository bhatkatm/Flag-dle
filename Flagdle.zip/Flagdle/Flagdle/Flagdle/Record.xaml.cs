﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Flagdle
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Record : ContentPage
    {        
        public ListView pubLV;
        public Record()
        {
            InitializeComponent();            
            if(DB.conn.Table<Records>().ToList() != null)
                lv.ItemsSource = DB.conn.Table<Records>().ToList();
            pubLV = lv;
        }
       
        private void ResetListViewSources()
        {
            lv.ItemsSource = DB.conn.Table<Records>().ToList();
            pubLV = lv;            
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();            
            ResetListViewSources();
        }

        /// <summary>
        /// Check for name (as guest and same name) done on other end
        /// </summary>
        /// <param name="name"></param>
        /// <param name="hasWon"></param>
        public void AddClicked(string name, bool hasWon)
        {
            if(!string.Equals(name, "guest", StringComparison.OrdinalIgnoreCase) && !string.Equals(name, ""))
            {
                Debug.WriteLine("In Add Clicked: " + name + hasWon);
                if (hasWon)
                {
                    Records record = new Records
                    {
                        Name = name,
                        Win = 1,
                        Loss = 0,
                        Percent = 100.00f
                    };
                    Debug.WriteLine(record);
                    Debug.WriteLine(DB.conn.Table<Records>().ToString());
                    DB.conn.Insert(record);
                    ResetListViewSources();
                }
                else
                {
                    Records record = new Records
                    {
                        Name = name,
                        Win = 0,
                        Loss = 1,
                        Percent = 0.00f
                    };
                    Debug.WriteLine(record);
                    Debug.WriteLine(DB.conn.Table<Records>().ToString());
                    DB.conn.Insert(record);
                    ResetListViewSources();
                }
            }
                     
        }        

        public void UpdateClicked(string name, bool hasWon)
        {
            if (!string.Equals(name, "guest", StringComparison.OrdinalIgnoreCase) && !string.Equals(name, ""))
            {
                Records oldRecords = new Records();
                Settings newSett = new Settings();

                foreach (Records rec in pubLV.ItemsSource)
                {
                    if (rec.Name.Equals(newSett.name))
                    {
                        oldRecords = rec;
                    }

                }

                int oldWin = oldRecords.Win;
                int oldLoss = oldRecords.Loss;
                double oldPercent;

                if (hasWon)
                {
                    oldWin++;
                    oldPercent = (double)(1.0 * oldWin / (oldWin + oldLoss)) * 100;
                    Records newRecords = new Records
                    {
                        Name = name,
                        Win = oldWin,
                        Loss = oldLoss,
                        Percent = oldPercent
                    };
                    newRecords.Id = oldRecords.Id;
                    Debug.WriteLine(newRecords);
                    Debug.WriteLine(DB.conn.Table<Records>().ToString());
                    DB.conn.Update(newRecords);
                    ResetListViewSources();
                }
                else
                {
                    oldLoss++;
                    oldPercent = (double)(1.0 * oldWin / (oldWin + oldLoss)) * 100;
                    Records newRecords = new Records
                    {
                        Name = name,
                        Win = oldWin,
                        Loss = oldLoss,
                        Percent = oldPercent
                    };
                    newRecords.Id = oldRecords.Id;
                    Debug.WriteLine(newRecords);
                    Debug.WriteLine(DB.conn.Table<Records>().ToString());
                    DB.conn.Update(newRecords);
                    ResetListViewSources();
                }
            }                        
        }
    }
}