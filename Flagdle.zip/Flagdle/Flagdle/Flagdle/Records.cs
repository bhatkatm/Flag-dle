﻿using System;
using System.Collections.Generic;
using System.Text;
using Flagdle;
using SQLite;
namespace Flagdle
{

    [Table("records")]
    public class Records
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string Name { get; set; }
        public int Win { get; set; }
        public int Loss { get; set; }
        public double Percent { get; set; }
                

        public override string ToString()
        {            
            return string.Format("{0} \t\t     {1} \t\t {2} \t\t  {3}", Name, Win, Loss, Math.Round(Percent, 2).ToString());          
        }
    }
}
