﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Flagdle
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Settings : ContentPage
    {
        public bool darkToggle = true;
        public string name = "";
        public Settings()
        {
            InitializeComponent();
            darkToggle = darkTheme.IsToggled;
            if (!Preferences.ContainsKey("ThemeMode"))
                Preferences.Set("ThemeMode", true);
            darkTheme.IsToggled = Preferences.Get("ThemeMode", true);            

            //DateTime x = new DateTime(2000, 01, 01);
            string x = "";
            if (!Preferences.ContainsKey("nameMode"))
                Preferences.Set("nameMode", x);
            nameEntry.Text = Preferences.Get("nameMode", x);

        }
        
        // This is used to create a webpage
        public async void CreditClicked(object sender, EventArgs e)
        {
            try
            {
                await Browser.OpenAsync("https://sites.google.com/view/tanmay-bhatkar/home", BrowserLaunchMode.SystemPreferred);
            }
            catch (Exception)
            {
                // An unexpected error occured. No browser may be installed on the device.
            }
        }

        private void nameEntry_TextChanged(object sender, TextChangedEventArgs e)
        {
            Preferences.Set("nameMode", nameEntry.Text);
            name = nameEntry.Text;
        }

        private void darkTheme_Toggled(object sender, ToggledEventArgs e)
        {
            Preferences.Set("ThemeMode", darkTheme.IsToggled);
            if (darkTheme.IsToggled)
            {
                labM.Text = "Theme: Dark";
                topLevelSett.BackgroundColor = Color.Black;
                labM.TextColor = Color.White;
                button.TextColor= Color.Black;
                nameLabel.TextColor = Color.White;
                nameEntry.BackgroundColor= Color.Black;
                nameEntry.TextColor= Color.White;
                darkTheme.BackgroundColor = Color.White;
                darkTheme.ThumbColor = Color.White;                                        
            }
            else
            {
                labM.Text = "Theme: Light";
                topLevelSett.BackgroundColor = Color.White;
                labM.TextColor= Color.Black;
                button.TextColor = Color.White;
                nameLabel.TextColor = Color.Black;
                nameEntry.BackgroundColor = Color.White;
                nameEntry.TextColor = Color.Black;
                darkTheme.BackgroundColor = Color.Black;
                darkTheme.ThumbColor= Color.Black;
                darkTheme.OnColor = Color.Black;                
            }
                
            darkToggle = darkTheme.IsToggled;
        }
    }
}